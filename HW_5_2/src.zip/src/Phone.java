public class Phone extends Product{
    public static String maker;
    public Phone(String title, int price, String maker){
        super(title, price);
        Phone.maker = maker;
    }
    @Override
    public String toString() {

        return "{" + this.title + "," + this.price + "," + Phone.maker + '}';
    }
}
