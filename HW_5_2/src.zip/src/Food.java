import java.util.Date;

public class Food extends Product{
    static Date date;
    public Food(String title, int price, Date date){
        super(title, price);
        Food.date = date;
    }
    @Override
    public String toString() {

        return "{" + this.title + "," + this.price + "," + Food.date + '}';
    }
}
