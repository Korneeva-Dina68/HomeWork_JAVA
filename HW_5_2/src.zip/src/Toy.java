public class Toy extends Product{
    public static int age;
    public Toy(String title, int price, int age){
        super(title, price);
        Toy.age =age;
    }
    @Override
    public String toString() {

        return "{" + this.title + "," + this.price + "," + Toy.age + '}';
    }
}
