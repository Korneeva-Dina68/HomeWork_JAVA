import java.util.Arrays;
import java.util.Date;
public class Shop {
//    Product product1 = new Phone("A80", 40000, "Samsung");
//    Product product2 = new Toy("doll", 1000, 6);
//    Product product3 = new Food("milk", 200, new Date(1683799811554L));
//    Phone phone = (Phone) product1;
//    Toy toy = (Toy) product2;
//    Food food = (Food) product3;
//    Date date = new Date();

    public static Product[] product = {new Phone("A80", 40000, "Samsung"), new Phone("10lite", 15000, "Honor"), new Toy("bear", 2000, 3),
            new Toy("doll", 1000, 6), new Food("milk", 150, new Date(1683799811554L)), new Food("eggs", 100, new Date(1683699811554L)), new Food("bread", 50, new Date(1683499811554L))};
    public static Product[] findPhones(String maker) {
        int a=0;
        for (int i=0; i<product.length; i++){
            if (maker.equalsIgnoreCase(Phone.maker)) {
                a++;}
        }
        System.out.println(a);
        Product[] new_phone=new Product[a];
        int p=0;
        for (int i=0; i<product.length; i++) {
            if (maker.equalsIgnoreCase(Phone.maker)) {
                new_phone[p] = product[i];
                p++;
            }
        }
        return new_phone;
    }

    public static Product[] findToys(int age){
        int a=0;
        for (int i=0; i<product.length; i++){
            if (age>=Toy.age){
                a++;
            }
        }
        System.out.println(a);
        Product[] new_toy=new Product[a];
        int p=0;
        for (int i=0; i<product.length; i++) {
            if (age >= Toy.age) {
                new_toy[p] = product[i];
                p++;
            }
        }
        return new_toy;
    }
    public static Food[] findFood(Date date){
        int j=0;
        for (int i=0; i<product.length; i++){
            if (Food.date.equals(date)){
                j++;
            }
        }
        Food[] new_food=new Food[j];
        int k=0;
        for (Product value : product) {
            if (Food.date.equals(date)) {
                new_food[k] = (Food) value;
                k++;
            }
        }
        return new_food;
    }
    public static void main(String[] args) {

//        Shop shop = new Shop();
//        System.out.println(Arrays.toString(shop.getProduct(600)));
//        System.out.println(shop.containsProduct("костюм"));
//        System.out.println(shop.findTheCheapest());
        System.out.println(Arrays.toString(Shop.findPhones("Honor")));
        System.out.println(Arrays.toString(Shop.findToys(4)));
        System.out.println(Arrays.toString(Shop.findFood(new Date(1683799811554L))));
    }

}